<?php
include 'db.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Employee</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h1>Add Employee</h1>
    <form method="POST" action="add_employee_action.php">
        <label>Name:</label>
        <input type="text" name="name" required>
        <br>
        <label>Email:</label>
        <input type="email" name="email" required>
        <br>
        <label>Phone:</label>
        <input type="text" name="phone" required>
        <br>
        <label>Department:</label>
        <input type="text" name="department" required>
        <br>
        <label>Role:</label>
        <input type="text" name="role" required>
        <br>
        <label>Hire Date:</label>
        <input type="date" name="hire_date" required>
        <br>
        <input type="submit" value="Add Employee">
    </form>
</div>
</body>
</html>
