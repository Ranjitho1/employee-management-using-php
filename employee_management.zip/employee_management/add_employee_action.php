<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $department = $_POST['department'];
    $role = $_POST['role'];
    $hire_date = $_POST['hire_date'];

    $stmt = $conn->prepare("INSERT INTO employees (name, email, phone, department, role, hire_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $email, $phone, $department, $role, $hire_date);

    if ($stmt->execute()) {
        echo "Employee added successfully.";
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
$conn->close();
?>
