<!DOCTYPE html>
<html>
<head>
    <title>Employee Details</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <?php
        include 'db.php';
        $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
        $stmt->bind_param("i", $_GET['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $employee = $result->fetch_assoc();
    ?>
    <h1>Employee Details</h1>
    <p>Name: <?php echo $employee['name']; ?></p>
    <p>Email: <?php echo $employee['email']; ?></p>
    <p>Phone: <?php echo $employee['phone']; ?></p>
    <p>Department: <?php echo $employee['department']; ?></p>
    <p>Role: <?php echo $employee['role']; ?></p>
    <p>Hire Date: <?php echo $employee['hire_date']; ?></p>
    <h2>Attendance Record</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $stmt = $conn->prepare("SELECT * FROM attendance WHERE employee_id = ?");
                $stmt->bind_param("i", $_GET['id']);
                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['date'] . "</td>";
                    echo "<td>" . $row['status'] . "</td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
</body>
</html>