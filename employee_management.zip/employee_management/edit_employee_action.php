<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $department = $_POST['department'];
    $role = $_POST['role'];
    $hire_date = $_POST['hire_date'];

    $stmt = $conn->prepare("UPDATE employees SET name=?, email=?, phone=?, department=?, role=?, hire_date=? WHERE id=?");
    $stmt->bind_param("sssssii", $name, $email, $phone, $department, $role, $hire_date, $id);

    if ($stmt->execute()) {
        echo "Employee updated successfully.";
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
$conn->close();
?>
