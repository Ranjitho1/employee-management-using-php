<?php
include 'db.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$departments = []; 
$roles = []; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <h1>Employee Management System</h1>
    <a href="logout.php">Logout</a>
</header>
<div class="container">
    <h1>Employee List</h1>
    <a href="add_employee.php" class="btn">Add Employee</a>
    <form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label>Filter by Department:</label>
        <select name="department">
            <option value="">All Departments</option>
            <option value="">mca</option>
            <option value="">computer application</option>
            <option value="">web development</option>
            <?php foreach ($departments as $dept) { ?>
                <option value="<?php echo $dept; ?>"><?php echo $dept; ?></option>
            <?php } ?>
        </select>
        <label>Filter by Role:</label>
        <select name="role">
            <option value="">All Roles</option>
            <option value="">php</option>
            <option value="">full stack</option>
            <option value="">HR</option>
            <?php foreach ($roles as $role) { ?>
                <option value="<?php echo $role; ?>"><?php echo $role; ?></option>
            <?php } ?>
        </select>
        <button type="submit">Apply Filters</button>
    </form>
    <table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Department</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $sql = "SELECT * FROM employees";
                
                if (isset($_GET['department']) && !empty($_GET['department'])) {
                    $sql .= " WHERE department = '" . $_GET['department'] . "'";
                }
                if (isset($_GET['role']) && !empty($_GET['role'])) {
                    if (strpos($sql, 'WHERE') !== false) {
                        $sql .= " AND role = '" . $_GET['role'] . "'";
                    } else {
                        $sql .= " WHERE role = '" . $_GET['role'] . "'";
                    }
                }
                
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" . $row['phone'] . "</td>";
                        echo "<td>" . $row['department'] . "</td>";
                        echo "<td>" . $row['role'] . "</td>";
                        echo "<td><a href='view_employee.php?id=" . $row['id'] . "'>View</a> | <a href='edit_employee.php?id=" . $row['id'] . "'>Edit</a> | <a href='delete_employee.php?id=" . $row['id'] . "'>Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No employees found.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>
</body>
</html>
