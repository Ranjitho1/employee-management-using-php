<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-form">
            <img src="images/cartrabbit-logo.png" alt="Logo" class="logo">
            <h1>Login</h1>
            <form method="POST" action="login_action.php">
                <label>Username:</label>
                <input type="text" name="username" required>
                <br>
                <label>Password:</label>
                <input type="password" name="password" required>
                <br>
                <input type="submit" value="Login">
            </form>
            <p>Don't have an account? <a href="register.php">Register</a></p>
        </div>
    </div>
</body>
</html>
