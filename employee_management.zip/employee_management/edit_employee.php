<?php
include 'db.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo 'No rows';
    } else {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $email = $row['email'];
        $phone = $row['phone'];
        $department = $row['department'];
        $role = $row['role'];
        $hire_date = $row['hire_date'];
    }
    $stmt->close();
} else {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Employee</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h1>Edit Employee</h1>
    <form method="POST" action="edit_employee_action.php">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo $name; ?>" required>
        <br>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $email; ?>" required>
        <br>
        <label>Phone:</label>
        <input type="text" name="phone" value="<?php echo $phone; ?>" required>
        <br>
        <label>Department:</label>
        <input type="text" name="department" value="<?php echo $department; ?>" required>
        <br>
        <label>Role:</label>
        <input type="text" name="role" value="<?php echo $role; ?>" required>
        <br>
        <label>Hire Date:</label>
        <input type="date" name="hire_date" value="<?php echo $hire_date; ?>" required>
        <br>
        <input type="submit" value="Update Employee">
    </form>
</div>
</body>
</html>
